# Panel MOHURE - IA AL DÍA

Panel tipo Trello con las oportunidades del pipeline **MOHURE - IA AL DÍA** de GHL,
agrupadas en 4 columnas: Mejora Detectada, En marcha, Terminada, Esperando / Stand By.

Un GitHub Action se ejecuta cada 15 minutos, consulta la API de GHL y genera
`data.json`. `index.html` lee ese archivo y pinta el tablero. El token de GHL
solo vive como secreto del repositorio — nunca aparece en el HTML ni en el
código público.

## 1. Crear el repositorio

1. En GitHub, crea un repositorio nuevo llamado `panel-mohure-ia-al-dia` (puede ser privado).
2. Sube todos los archivos de esta carpeta a ese repositorio (arrastrándolos en la web de GitHub, o con `git push` si usas terminal).

## 2. Añadir el token de GHL como secreto

1. En el repo, ve a **Settings → Secrets and variables → Actions → New repository secret**.
2. Nombre: `GHL_API_TOKEN`
3. Valor: pega tu Private Integration Token de GHL (Configuración de la sub-cuenta → Integraciones → Private Integrations). Necesita permiso de lectura sobre Opportunities y Custom Fields.
4. Guarda.

No hace falta tocar nada más — el Location ID, el nombre del pipeline y el
campo de descripción ya están configurados en `.github/workflows/sync-ghl.yml`.

## 3. Activar GitHub Pages

1. En el repo, ve a **Settings → Pages**.
2. En "Build and deployment" → Source, elige **Deploy from a branch**.
3. Branch: `main`, carpeta `/ (root)`. Guarda.
4. En el mismo panel, en "Custom domain" escribe `mohure.neverwork.com` y guarda (el archivo `CNAME` ya está en el repo, así que puede que lo detecte solo).

## 4. Configurar el DNS

En el proveedor DNS donde gestionas `neverwork.com`, añade un registro:

- Tipo: `CNAME`
- Nombre/host: `mohure`
- Valor/destino: `<tu-usuario-de-github>.github.io`

(Sustituye `<tu-usuario-de-github>` por tu usuario u organización de GitHub —
es el mismo que usas para crear el repositorio.)

La propagación puede tardar unos minutos. Cuando esté lista, GitHub emitirá
un certificado HTTPS automáticamente para el dominio (puede tardar hasta un
par de horas la primera vez) — activa "Enforce HTTPS" en Settings → Pages
cuando esté disponible.

## 5. Primera sincronización

Los Actions programados no se disparan automáticamente hasta que el
workflow lleva un rato en `main`. Para forzar la primera sincronización sin
esperar:

1. Ve a la pestaña **Actions** del repo.
2. Selecciona el workflow "Sincronizar oportunidades GHL".
3. Pulsa **Run workflow**.

Revisa el log de esa ejecución: si el pipeline o algún stage no coincide
exactamente con los nombres configurados, el script lo indica ahí (te dice
qué pipelines encontró, o qué stage no pudo mapear).

## Repetir esto para otro cliente

Cuando quieras un panel nuevo para otro cliente: copia esta carpeta, cambia
en `.github/workflows/sync-ghl.yml` el `GHL_LOCATION_ID`, `GHL_PIPELINE_NAME`
y `GHL_DESC_FIELD_KEY`, ajusta las 4 etiquetas/columnas en `scripts/sync.js`
y en `index.html` si cambian, cambia el `CNAME` al subdominio del nuevo
cliente, y repite los pasos 1-4 con un repo nuevo.

## Notas técnicas

- La API de GHL usada es la v2 (`services.leadconnectorhq.com`), con el
  header `Version: 2021-07-28`.
- El campo "descripción" se busca por `fieldKey` (`opportunity.descripcion`)
  entre los custom fields de la location; si no lo encuentra por key, hace un
  segundo intento buscando un campo cuyo nombre contenga "descrip".
- Si GHL cambia los nombres de los stages, actualiza `COLUMN_ORDER` en
  `scripts/sync.js`.
